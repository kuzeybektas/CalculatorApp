Title: CalculatorApp

Description: A calculator app designed by Kuzey Bektas for C323 Mobile App development

Functionality: The app has the functionality of a simple calculator, doing basic operations. It can work with decimals, 
do + - / % and * operations, clear its screen and flip the sign of numbers

Extensions: none were used for the project

Video: https://youtu.be/j_yUZxhSupA

license: standard mit license
